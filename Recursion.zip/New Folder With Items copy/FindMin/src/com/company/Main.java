package com.company;
import java.util.Scanner;

public class Main {
    public static int findMin(int A[], int n) {
        if (n == 1)
            return A[0];

        return Math.min(A[n - 1], findMin(A, n - 1));
    }
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int[] A = new int[1000];
        int n = sc.nextInt();
        for(int i = 0; i < n; ++i){
            A[i] = sc.nextInt();
        }

        System.out.println(findMin(A, n));
    }
}


package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int pos = 0 ;
        reverse(pos,n);
    }
    public static void reverse(int pos, int n){
        if(pos == n)
            return;
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        reverse(pos + 1, n);
        System.out.println(a + "");


    }
}
package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String s = scan.nextLine();
        numbers(s);
    }
    public static void numbers(String s) {
        if (s.length() == 1) {
            if (s.charAt(s.length() - 1) >= '0' && s.charAt(s.length() - 1) <= '9')
                System.out.println("Yes");
            else
                System.out.println("No");
            return;
        }
        if (!(s.charAt(s.length() - 1) >= '0' && s.charAt(s.length() - 1) <= '9')) {
            System.out.println("No");
            return;
        }
        numbers(s.substring(0, s.length() - 1));
    }
}

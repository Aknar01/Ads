package com.company;

import java.util.Scanner;

public class Main {
    public static double Average(int[] array, int n){
        double b = 0;
    for(int i = 0; i < n; ++i){
            b += array[i];
        }
        return b/n;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] array = new int[1000];
        int n = sc.nextInt();
        for(int i = 0; i < n; ++i){
            array[i] = sc.nextInt();
        }

        System.out.println(Average(array, n));
    }
}

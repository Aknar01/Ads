package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        int n = scan.nextInt();
        System.out.println(power(a,n));
    }
    public static int power(int a,int n){
        if(n == 1){
            return a;
        }
        return a * power(a, n - 1);
    }
}

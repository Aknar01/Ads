package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        int num=scan.nextInt();
        System.out.println(primeNumber(num));
        }
    public static String primeNumber(int num){
        int temp;
        boolean isPrime=true;
        for(int i=2;i<=num/2;i++){
            temp=num%i;
            if(temp==0) {
                isPrime=false;
                break;
            }
        }
        if(isPrime)
            return "Prime";
        else
            return "Composite";
    }
}

